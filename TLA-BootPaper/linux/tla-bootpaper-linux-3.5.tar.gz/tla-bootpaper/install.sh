#!/bin/bash
# install.sh - installs or updates TLA BootPaper for Linux (Ubuntu with GNOME). Run as root, from the unpacked
# bundle, by the Intune Linux script (bootstrap.sh). Takes effect at each person's next login; the TLA BootPaper
# app is in Activities straight away.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST=/opt/tla-bootpaper
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> /var/log/tla-bootpaper.log; echo "$*"; }
[ "$(id -u)" = 0 ] || { echo "install.sh must run as root"; exit 1; }
log "---- TLA BootPaper $(cat "$HERE/VERSION") installing ----"

# What it needs: mpv (plays the H.264 intro videos) and Python's GTK bindings (the app window).
need=()
for p in mpv python3-gi gir1.2-gtk-3.0; do dpkg -s "$p" >/dev/null 2>&1 || need+=("$p"); done
if [ ${#need[@]} -gt 0 ]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get install -y --no-install-recommends "${need[@]}" >/dev/null 2>&1 \
    || { apt-get update >/dev/null 2>&1; apt-get install -y --no-install-recommends "${need[@]}" >/dev/null 2>&1; } \
    || log "WARNING: couldn't install ${need[*]} (offline?); will try again next time."
fi

mkdir -p "$DEST/Backgrounds/thumbs" "$DEST/Videos" /etc/tla-bootpaper
cp -f "$HERE"/tla-bootpaper.py "$HERE"/mpv-skip.conf "$HERE"/mpv-noskip.conf "$HERE"/release-notes.md \
      "$HERE"/AppIcon.png "$DEST/"
cp -f "$HERE"/Backgrounds/*.jpg "$DEST/Backgrounds/"
cp -f "$HERE"/Backgrounds/thumbs/*.jpg "$DEST/Backgrounds/thumbs/"
cp -f "$HERE/org-defaults.json" /etc/tla-bootpaper/org-defaults.json
chown -R root:root "$DEST" /etc/tla-bootpaper
chmod -R go-w "$DEST" /etc/tla-bootpaper
chmod 755 "$DEST/tla-bootpaper.py"

mkdir -p /etc/xdg/autostart /usr/share/applications
cp -f "$HERE/tla-bootpaper-autostart.desktop" /etc/xdg/autostart/tla-bootpaper.desktop
cp -f "$HERE/tla-bootpaper.desktop" /usr/share/applications/tla-bootpaper.desktop
chmod 644 /etc/xdg/autostart/tla-bootpaper.desktop /usr/share/applications/tla-bootpaper.desktop
update-desktop-database /usr/share/applications >/dev/null 2>&1 || true

# The background guard: a system service, so people can't stop it.
cp -f "$HERE/tla-bootpaper-guard.service" "$HERE/tla-bootpaper-guard.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now tla-bootpaper-guard.timer >/dev/null 2>&1 || log "WARNING: couldn't start the background guard"

# The intro videos download in the background (full quality, checked against their SHA-256).
( /usr/bin/python3 "$DEST/tla-bootpaper.py" sync-videos >/dev/null 2>&1 && touch "$DEST/.videos-ok" ) &

cp -f "$HERE/VERSION" "$DEST/VERSION"
log "Done. Takes effect at each person's next login."
exit 0
