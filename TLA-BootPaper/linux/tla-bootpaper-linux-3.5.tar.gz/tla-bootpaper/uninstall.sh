#!/bin/bash
# uninstall.sh - removes TLA BootPaper for Linux. Run as root. People's own backgrounds stay as they are.
systemctl disable --now tla-bootpaper-guard.timer >/dev/null 2>&1
rm -f /etc/systemd/system/tla-bootpaper-guard.service /etc/systemd/system/tla-bootpaper-guard.timer
systemctl daemon-reload
rm -f /etc/xdg/autostart/tla-bootpaper.desktop /usr/share/applications/tla-bootpaper.desktop
rm -rf /opt/tla-bootpaper /etc/tla-bootpaper
echo "TLA BootPaper removed."
