#!/bin/bash
# uninstall.sh - removes TLA BootPaper for Linux. As root: the copy for everyone. As a person: their own copy.
# People's own backgrounds stay as they are.
if [ "$(id -u)" = 0 ]; then
  systemctl disable --now tla-bootpaper-guard.timer >/dev/null 2>&1
  rm -f /etc/systemd/system/tla-bootpaper-guard.service /etc/systemd/system/tla-bootpaper-guard.timer
  systemctl daemon-reload
  rm -f /etc/xdg/autostart/tla-bootpaper.desktop /usr/share/applications/tla-bootpaper.desktop
  rm -rf /opt/tla-bootpaper /etc/tla-bootpaper
else
  CONF="${XDG_CONFIG_HOME:-$HOME/.config}"; DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
  systemctl --user disable --now tla-bootpaper-guard.timer >/dev/null 2>&1
  rm -f "$CONF/systemd/user/tla-bootpaper-guard.service" "$CONF/systemd/user/tla-bootpaper-guard.timer"
  systemctl --user daemon-reload >/dev/null 2>&1
  rm -f "$CONF/autostart/tla-bootpaper.desktop" "$DATA/applications/tla-bootpaper.desktop"
  rm -rf "$DATA/tla-bootpaper"
fi
echo "TLA BootPaper removed."
