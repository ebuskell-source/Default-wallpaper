#!/usr/bin/python3
# TLA BootPaper for Linux (Ubuntu with GNOME). install.sh (run by the Intune Linux script) puts it in one of two places:
#   for everyone:     /opt/tla-bootpaper, when the script runs as root
#   for one person:   ~/.local/share/tla-bootpaper, when it runs as that person (Intune "User" context, 3.5.5),
#                     so nobody needs an administrator password. Same features; the background guard is a
#                     systemd user timer instead of a system one.
#
#   tla-bootpaper.py app                 the TLA BootPaper window (Activities > TLA BootPaper)
#   tla-bootpaper.py login               at every login (/etc/xdg/autostart): intro video, background, What's new
#   tla-bootpaper.py play                play the intro video now (always closable)
#   tla-bootpaper.py apply [--if-needed] put the person's preset background on their desktop and lock screen
#   tla-bootpaper.py guard               every 20 seconds (systemd timer): keeps the desktop to the preset (so the
#                                        background can only be changed in the app), downloads videos. As root it
#                                        looks after everyone; installed for one person, just that person
#   tla-bootpaper.py sync-videos         download any intro video that's missing or out of date
#   tla-bootpaper.py update              check GitHub for a new version now (the guard does this every 6 hours)
#
# Same choices and rules as the Windows and Mac versions:
#   Organization defaults: /etc/tla-bootpaper/org-defaults.json (people can change them for themselves unless
#                          UsersCanChange is 0)
#   Each person's choices: ~/.config/tla-bootpaper/settings.json (only what differs from the defaults)
#   What has happened:     ~/.config/tla-bootpaper/state.json

import datetime
import hashlib
import json
import os
import platform
import pwd
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

APP_DIR = os.path.dirname(os.path.abspath(__file__))
RELEASE = '4.1'
ORG_FILE = '/etc/tla-bootpaper/org-defaults.json'
HELPDESK = 'helpdesk@schoolathome.ca'
VIDEO_SOURCE = 'https://raw.githubusercontent.com/ebuskell-source/Default-wallpaper/main/TLA-BootPaper/videos'
VIDEO_DIR = os.path.join(APP_DIR, 'Videos')
# The Intune Linux script, also used to update itself (3.6): see self_update().
UPDATE_SCRIPT = 'https://raw.githubusercontent.com/ebuskell-source/Default-wallpaper/main/TLA-BootPaper/linux/tla-bootpaper-linux.sh'
# Announcements (4.0): a text file on GitHub that the organization edits. (Intune only reaches these computers
# while the admin account is signed in, so it can't deliver them.) Shown on the login screen and at login.
ANNOUNCEMENT_URL = 'https://raw.githubusercontent.com/ebuskell-source/Default-wallpaper/main/TLA-BootPaper/linux/announcement.txt'
ANNOUNCEMENT_FILE = '/etc/tla-bootpaper/announcement.txt'
LOG_FILE = '/var/log/tla-bootpaper.log'

SETTINGS = ['Enabled', 'PlayWhen', 'Sound', 'AllowSkip', 'Background', 'Video', 'QuietMode', 'QuietStart',
            'QuietEnd', 'QuietDays', 'PreferredName']
DEFAULTS = {'Enabled': 1, 'PlayWhen': 'EverySignIn', 'Sound': 1, 'AllowSkip': 0, 'Background': 'penguins',
            'Video': 'match', 'QuietMode': 'Off', 'QuietStart': '08:30', 'QuietEnd': '15:00',
            'QuietDays': 'Mon,Tue,Wed,Thu,Fri', 'PreferredName': '', 'UsersCanChange': 1}
PLAY_WHEN = [('EverySignIn', 'Every time I log in'),
             ('OncePerDay', 'Once a day, the first time I log in'),
             ('AfterUpdate', 'Only after Ubuntu installs an update'),
             ('FirstTime', "Only once, and again when there's a new video")]
# Quiet hours (4.0): the intro video plays without sound. Off unless the person turns it on.
QUIET_MODES = [('Off', "Don't mute it"),
               ('DoNotDisturb', 'Mute it while Do Not Disturb is on'),
               ('Hours', 'Mute it during these hours')]
DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
TIMES = ['%02d:%02d' % (h, m) for h in range(24) for m in (0, 15, 30, 45)]
SURPRISE = 'surprise'       # Background: a different one each day. Video: a different one each time.
NAME_MAX = 30
# The only backgrounds people can choose (desktop and lock screen). Backgrounds/<id>.jpg, thumbs/<id>.jpg.
# The ones with no intro video (not in VIDEOS) are listed in their own "coming soon" section.
BACKGROUNDS = [('microsoft', 'Microsoft'), ('liquid-glass', 'Liquid Glass'), ('penguins', 'Penguins'),
               ('code', 'Code'), ('frutiger-aero', 'Frutiger Aero'), ('solarpunk', 'Solarpunk'),
               ('rainy', 'Rainy'), ('space', 'Space'), ('ocean', 'Underwater'), ('claymation', 'Claymation'),
               ('blocks', 'Blocks'), ('bricks', 'Bricks'), ('pixel', '8-Bit'), ('anime', 'Anime'), ('tla', 'TLA Classic')]
# The intro videos (downloaded to Videos/<id>.mp4, kept only if the SHA-256 matches). 'match' = the video that
# goes with the person's background.
VIDEO_HASHES = {
    'tla':                    '7cb60be851fbcdf6a60176a524c3dee051cca3da8295be3a49cda3927f51fa9b',
    'frutiger-aero':          'b01287343a0b89460dc9c4403fb10ffff79cb61c7b21b6cb03c067656c3895da',   # (4.1: the original again)
    'liquid-glass':           'fd3e3510cad5bfcdd5557bf1050d05b2a2d3452c7ef83ca07bc2c68138cb391f',
    'microsoft':              'd49eea24251e2424af6bed3ca5c33dd4abd2e184ec22aea11f837361697e30e7',
    'rainy':                  '7ae3580eb8bb70a1a692d764bca77a5670ada051262e4b208831c277c32899a7',
    'code':                   '0e8eea44df385807898f8b732aeb804fdd3b14c1d9d169fceebbdb0993f36b02',
    'bricks':                 '0c19192e6e13ef23946055a4593c1abba2dde8cace81408918d5a063c2488afd',   # (4.1: V2)
    'blocks':                 '0ce92e5a85115c42e8cd02cc994914300cd50158e66776e5035e1103cacdb7a3',
    'space':                  '1c9f81b94905fde5dfc765ed09a59b371aef771d4b79a752258c306791ef8db5',
    'claymation':             'dc729567f37032a23aa71d139cb663d22b1e469cb4c66d18bf8021d4fba9f503',
    'anime':                  'b0fc2c29f5305fe57e3617073227a9a8137f18337d5429fa74611f61653bdcaa',
    'penguins':               '2f6f7adbeadbe959e72218b194c0de7ca43d5596a8f67a2c76bd0743ef7434eb',
    'solarpunk':              '725ec78d91c5935963345c60f5b703f36fe017ca40cd47d6501fa956f05d304e',
    'pixel':                  '3feef1c0d359950e00b42b4a3db355e31b73cf457736947c0bbc286d56b45930',
    'ocean':                  '6def8de6af1e729d56d8fa8e224d85d7a7a36993c8e772ff33fa75048020e803',
    'frutiger-aero-v2':       'bbce9fec534928fbae3dbe94e9f5a368f92aba439454ce8882df60fb8cf22460',   # (the 3.4.3 one)
    'liquid-glass-original':  '5dae894482e3cd513baf6214da8a340f9da38ccb7f7589507c39b71bb26afbdf',
    'microsoft-original':     'b781ce6a57156694d5ec85a6dfc6e2521785a7afefcbda2e10a5b985277eb4f8',
    # The seasonal themes' own videos (4.1): played by "Match my background" during the season.
    'fall':                   '9b2828fd96159967445718a8621265781397989135b8021bfeb6c18640fd9767',
    'christmas':              '6f22a687f31f120627804a3db693c0d6b4d7c588b66fdc3c730a1165a29718eb',
    'easter':                 'e68f1b26c63672fcece100904d81c5ad83250d449d45059bc361ac7101482f98',
}
# Other versions of some videos, still there for anyone who prefers them: Frutiger Aero's newer video (4.1: its
# original is the main one again), and the originals of Liquid Glass and Microsoft.
ORIGINAL_VIDEOS = [('frutiger-aero-v2', 'Frutiger Aero (newer version)'), ('liquid-glass-original', 'Liquid Glass (original)'),
                   ('microsoft-original', 'Microsoft (original)')]
# 4.1: an earlier choice of Frutiger Aero's original keeps it (it's "Frutiger Aero" again).
ALIASES = {('Video', 'frutiger-aero-original'): 'frutiger-aero'}
VIDEOS = ([('match', 'Match my background'), (SURPRISE, 'Surprise me (a different one each time)')] +
          [(i, n) for i, n in BACKGROUNDS if i in VIDEO_HASHES] + ORIGINAL_VIDEOS)
# Seasonal themes (4.0): during its season, everyone still on the organization's default background gets the
# seasonal one instead (desktop and lock screen). Picking any background yourself keeps yours. They aren't in the
# picker. 4.1: they have their own intro videos (the default background's plays until it's downloaded).
SEASONAL = [('fall', 'Fall'), ('christmas', 'Christmas'), ('easter', 'Easter')]
SEASON_ENDS = {'fall': 'November 30', 'christmas': 'January 6', 'easter': 'Easter Monday'}
BG_NAMES = dict(BACKGROUNDS + SEASONAL + [(SURPRISE, 'Surprise me')])


# ---- settings ---------------------------------------------------------------------------------------------------
def config_dir():
    d = os.path.join(os.environ.get('XDG_CONFIG_HOME') or os.path.expanduser('~/.config'), 'tla-bootpaper')
    os.makedirs(d, exist_ok=True)
    return d


def read_json(path):
    try:
        with open(path) as f:
            v = json.load(f)
            return v if isinstance(v, dict) else {}
    except Exception:
        return {}


def write_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f, indent=1)
    os.replace(tmp, path)


def valid(name, value):
    if name == 'PlayWhen':
        return value in [p for p, _ in PLAY_WHEN]
    if name == 'Background':
        return value in dict(BACKGROUNDS) or value == SURPRISE
    if name == 'Video':
        return value in [v for v, _ in VIDEOS]
    if name == 'QuietMode':
        return value in [q for q, _ in QUIET_MODES]
    if name in ('QuietStart', 'QuietEnd'):
        return value in TIMES
    if name == 'QuietDays':
        return isinstance(value, str) and all(d in DAYS for d in value.split(',') if d)
    if name == 'PreferredName':
        return isinstance(value, str) and len(value) <= NAME_MAX and value.isprintable()
    return value in (0, 1)


def org(name):
    v = read_json(ORG_FILE).get(name)
    if isinstance(v, bool):
        v = int(v)
    return v if (name == 'UsersCanChange' and v in (0, 1)) or valid(name, v) else DEFAULTS[name]


def users_can_change():
    return org('UsersCanChange') != 0


def mine():
    return read_json(os.path.join(config_dir(), 'settings.json'))


def setting(name):
    if users_can_change():
        v = mine().get(name)
        v = ALIASES.get((name, v), v)
        if valid(name, v):
            return v
    return org(name)


def save(name, value):
    """Saves a choice. Matching the organization default removes it, so later default changes still apply.
    A background picked in the app is always kept (even the default one): it's what tells the seasonal themes
    this person chose their own."""
    s = mine()
    if value == org(name) and name != 'Background':
        s.pop(name, None)
    else:
        s[name] = value
    write_json(os.path.join(config_dir(), 'settings.json'), s)


def state():
    return read_json(os.path.join(config_dir(), 'state.json'))


def set_state(**kw):
    s = state()
    s.update(kw)
    write_json(os.path.join(config_dir(), 'state.json'), s)


def log(text):
    path = os.path.join(config_dir(), 'tla-bootpaper.log') if os.geteuid() else LOG_FILE
    try:
        if os.path.exists(path) and os.path.getsize(path) > 65536:
            os.replace(path, path + '.old')
        with open(path, 'a') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + text + '\n')
    except Exception:
        pass


# ---- backgrounds ------------------------------------------------------------------------------------------------
def background_path(bg_id):
    return os.path.join(APP_DIR, 'Backgrounds', bg_id + '.jpg')


def thumb_path(bg_id):
    return os.path.join(APP_DIR, 'Backgrounds', 'thumbs', bg_id + '.jpg')


def gsettings(*args):
    try:
        return subprocess.run(['gsettings'] + list(args), capture_output=True, text=True, timeout=10).stdout.strip()
    except Exception:
        return ''


def background_locked():
    """True when the system (dconf locks, set by another policy) doesn't let people change the desktop picture."""
    return gsettings('writable', 'org.gnome.desktop.background', 'picture-uri') == 'false'


def today():
    """Today's date (TLA_TODAY=YYYY-MM-DD overrides it, for testing the seasons)."""
    try:
        return datetime.date.fromisoformat(os.environ['TLA_TODAY'])
    except (KeyError, ValueError):
        return datetime.date.today()


def easter_sunday(year):
    """Western (Gregorian) Easter Sunday: the Anonymous Gregorian algorithm."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 19 * l) // 433
    month = (h + l - 7 * m + 90) // 25
    return datetime.date(year, month, (h + l - 7 * m + 33 * month + 19) % 32)


def season(day=None):
    """The seasonal theme in effect: Fall Sep 22 - Nov 30, Christmas Dec 1 - Jan 6, Easter from two weeks before
    Easter Sunday to Easter Monday. None the rest of the year."""
    d = day or today()
    if (d.month == 9 and d.day >= 22) or d.month in (10, 11):
        return 'fall'
    if d.month == 12 or (d.month == 1 and d.day <= 6):
        return 'christmas'
    e = easter_sunday(d.year)
    if e - datetime.timedelta(days=14) <= d <= e + datetime.timedelta(days=1):
        return 'easter'
    return None


def on_default_background():
    """True for someone who hasn't picked a background themselves (or can't: the organization decides)."""
    return not users_can_change() or not valid('Background', mine().get('Background'))


def surprise_background():
    """A different background each day (never the same two days running), the same all day."""
    st, day = state(), today().isoformat()
    if st.get('SurpriseDay') == day and st.get('SurpriseBackground') in dict(BACKGROUNDS):
        return st['SurpriseBackground']
    import random
    pick = random.choice([b for b, _ in BACKGROUNDS if b != st.get('SurpriseBackground')])
    set_state(SurpriseDay=day, SurpriseBackground=pick)
    return pick


def current_background():
    """The background to show today: the seasonal theme for people on the default, a daily pick for "Surprise me",
    otherwise the one chosen."""
    s = season()
    if s and on_default_background() and os.path.exists(background_path(s)):
        return s
    bg = setting('Background')
    return surprise_background() if bg == SURPRISE else bg


def background_needed():
    want = 'file://' + background_path(current_background())
    for schema, key in (('org.gnome.desktop.background', 'picture-uri'),
                        ('org.gnome.desktop.background', 'picture-uri-dark'),
                        ('org.gnome.desktop.screensaver', 'picture-uri')):
        if gsettings('get', schema, key).strip("'") != want:
            return True
    return gsettings('get', 'org.gnome.desktop.background', 'picture-options').strip("'") != 'zoom'


def apply_background(if_needed=False):
    if background_locked():
        log('The desktop picture is locked by another policy; not changing it.')
        return False
    bg = current_background()
    path = background_path(bg)
    if not os.path.exists(path):
        log('Background file missing: ' + path)
        return False
    if if_needed and not background_needed():
        return True
    uri = 'file://' + path
    # Desktop (light and dark style) and the lock screen. "zoom" fills the screen; the pictures have spare room
    # above and below, so the logo is the same size as in the intro video.
    gsettings('set', 'org.gnome.desktop.background', 'picture-uri', uri)
    gsettings('set', 'org.gnome.desktop.background', 'picture-uri-dark', uri)
    gsettings('set', 'org.gnome.desktop.background', 'picture-options', 'zoom')
    gsettings('set', 'org.gnome.desktop.screensaver', 'picture-uri', uri)
    gsettings('set', 'org.gnome.desktop.screensaver', 'picture-options', 'zoom')
    set_state(AppliedBackground=bg)
    log('Desktop and lock screen set to %s.' % bg)
    return True


# ---- intro video ------------------------------------------------------------------------------------------------
def video_path(vid):
    return os.path.join(VIDEO_DIR, vid + '.mp4')


def surprise_video(pick):
    """For "Surprise me": a different video each time it plays (never the same twice running)."""
    last = state().get('SurpriseVideo')
    if not pick:
        return last if last in VIDEO_HASHES else 'tla'
    import random
    have = [v for v, _ in VIDEOS if v in VIDEO_HASHES and os.path.exists(video_path(v))]
    choices = [v for v in have if v != last] or have or ['tla']
    v = random.choice(choices)
    set_state(SurpriseVideo=v)
    return v


def match_video():
    """What "Match my background" plays: the background's own video. A seasonal theme plays its own (4.1), or the
    default background's until that's downloaded."""
    v = current_background()
    if v in dict(SEASONAL) and not os.path.exists(video_path(v)):
        v = org('Background')
    return v


def video_file(pick=False):
    """The intro video to play. pick=True when it's about to play (Surprise me picks a new one then)."""
    v = setting('Video')
    if v == SURPRISE:
        v = surprise_video(pick)
    elif v == 'match':
        v = match_video()
    if os.path.exists(video_path(v)):
        return video_path(v)
    return video_path('tla')          # a background with no video of its own (yet)


def do_not_disturb():
    return gsettings('get', 'org.gnome.desktop.notifications', 'show-banners') == 'false'


def quiet_now(now=None):
    """Quiet hours (4.0): mute the intro video while Do Not Disturb is on, or during the hours (and days) set."""
    mode = setting('QuietMode')
    if mode == 'DoNotDisturb':
        return do_not_disturb()
    if mode != 'Hours':
        return False
    now = now or datetime.datetime.now()
    start, end = (int(t[:2]) * 60 + int(t[3:]) for t in (setting('QuietStart'), setting('QuietEnd')))
    minute = now.hour * 60 + now.minute
    days = setting('QuietDays').split(',')
    if start <= end:
        return DAYS[now.weekday()] in days and start <= minute < end
    # Overnight (e.g. 21:00 - 07:00): the evening part counts for that day, the morning part for the day before.
    if minute >= start:
        return DAYS[now.weekday()] in days
    return minute < end and DAYS[(now.weekday() - 1) % 7] in days


def greeting(now=None):
    """'Good morning, Audrey!' over the start of the video, when the person has given their name."""
    name = ' '.join(str(setting('PreferredName')).split())
    if not name:
        return ''
    h = (now or datetime.datetime.now()).hour
    return 'Good %s, %s!' % ('morning' if h < 12 else 'afternoon' if h < 17 else 'evening', name)


def video_key():
    try:
        st = os.stat(video_file())
        return '%d-%d' % (st.st_size, int(st.st_mtime))
    except OSError:
        return ''


def play_video(force=False):
    video = video_file(pick=True)
    if not os.path.exists(video):
        log('No intro video yet (they download after the install).')
        return False
    skip = force or setting('AllowSkip') == 1
    quiet = setting('Sound') == 1 and quiet_now()
    mute = setting('Sound') != 1 or quiet
    greet = greeting()
    how = '%s, skip %d%s%s' % ('now' if force else 'login', int(skip), ', quiet hours' if quiet else '',
                               ', with greeting' if greet else '')
    if not force:
        set_state(LastPlayed=time.strftime('%Y-%m-%d %H:%M'), LastPlayedDay=time.strftime('%Y-%m-%d'),
                  LastPlayedVideo=video_key())
    if not shutil.which('mpv'):
        # Installed without an administrator, mpv may be missing: GStreamer (part of Ubuntu's desktop) plays it.
        log('Playing %s with GStreamer (%s).' % (os.path.basename(video), how))
        try:
            subprocess.run([sys.executable, os.path.abspath(__file__), 'gst-play', video, str(int(skip)),
                            str(int(mute)), greet], timeout=190)
        except Exception as e:
            log('Could not play the video: %s' % e)
            return False
        return True
    conf = os.path.join(APP_DIR, 'mpv-skip.conf' if skip else 'mpv-noskip.conf')
    cmd = ['mpv', '--fs', '--ontop', '--no-border', '--no-osc', '--osd-level=0', '--no-input-default-bindings',
           '--input-conf=' + conf, '--keep-open=no', '--really-quiet', '--force-window=immediate',
           '--background=color', '--background-color=#000000', '--no-terminal', '--title=TLA BootPaper',
           '--cursor-autohide=always', '--mute=' + ('yes' if mute else 'no')]
    if greet:
        # Shown for the first 4.5 seconds, low in the picture so it doesn't cover the logo. ("$" is special in
        # mpv's message text, so it's doubled.)
        cmd += ['--osd-level=1', '--osd-playing-msg=' + greet.replace('$', '$$'), '--osd-duration=4500',
                '--osd-font-size=58', '--osd-bold=yes', '--osd-align-x=center', '--osd-align-y=bottom',
                '--osd-margin-y=60', '--osd-border-size=2.5', '--osd-shadow-offset=1.5']
    cmd.append(video)
    log('Playing %s (%s).' % (os.path.basename(video), how))
    try:
        subprocess.run(cmd, timeout=180)
    except Exception as e:
        log('Could not play the video: %s' % e)
        return False
    return True


def os_build():
    try:
        return platform.freedesktop_os_release().get('VERSION_ID', '') + ' ' + platform.release()
    except Exception:
        return platform.release()


def login():
    if os.geteuid() == 0:
        return
    # Once per login session (the autostart entry can run twice if the session restarts).
    session = os.environ.get('XDG_SESSION_ID', '0')
    marker = os.path.join('/run/user', str(os.getuid()), 'tla-bootpaper-' + session)
    try:
        os.close(os.open(marker, os.O_CREAT | os.O_EXCL))
    except FileExistsError:
        return
    except OSError:
        pass
    # Background first (fast), then the video.
    apply_background(if_needed=True)
    if not os.access(APP_DIR, os.W_OK):
        pass                              # installed for everyone: the root guard downloads the videos
    else:
        # Installed for this person: make sure their guard timer is running (the install may not have been
        # able to reach systemd), and that the videos are coming down.
        unit = os.path.join(os.environ.get('XDG_CONFIG_HOME') or os.path.expanduser('~/.config'),
                            'systemd', 'user', 'tla-bootpaper-guard.timer')
        if os.path.exists(unit):
            try:
                subprocess.run(['systemctl', '--user', 'daemon-reload'], capture_output=True, timeout=20)
                subprocess.run(['systemctl', '--user', 'enable', '--now', 'tla-bootpaper-guard.timer'],
                               capture_output=True, timeout=20)
            except Exception:
                pass
    if os.access(APP_DIR, os.W_OK) and not os.path.exists(os.path.join(APP_DIR, '.videos-ok')):
        subprocess.Popen([sys.executable, os.path.abspath(__file__), 'guard'], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    build = os_build()
    st = state()
    play = setting('Enabled') == 1
    when = setting('PlayWhen')
    if when == 'OncePerDay' and st.get('LastPlayedDay') == time.strftime('%Y-%m-%d'):
        play = False
    elif when == 'AfterUpdate' and (not st.get('LastSeenBuild') or st.get('LastSeenBuild') == build):
        play = False
    elif when == 'FirstTime' and st.get('LastPlayedVideo') == video_key():
        play = False
    if play:
        play_video()
    set_state(LastSeenBuild=build)
    text = announcement()
    if text:
        notify('Announcement', text)
    # Once (4.0): ask what name to greet them by. They can skip it, and change it later in the app. 4.0.5: only
    # "Save" or "Not now" count as answered; closed any other way, it's asked again next login (at most 3 times).
    if users_can_change() and setting('Enabled') == 1 and not state().get('NameAsked'):
        tries = int(state().get('NameTries') or 0) + 1
        set_state(NameTries=tries, **({'NameAsked': 1} if tries >= 3 else {}))
        run_app(ask_name_only=True)
    if state().get('SeenRelease') != RELEASE:
        set_state(SeenRelease=RELEASE)
        run_app(whats_new_only=True)


# ---- announcements ----------------------------------------------------------------------------------------------
def clean_announcement(text):
    """The announcement text: comment lines (starting with #) and blank lines dropped, at most 300 characters."""
    lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith('#')]
    text = ' '.join(lines)
    return ''.join(c for c in text if c.isprintable())[:300].strip()


def announcement():
    try:
        return clean_announcement(open(ANNOUNCEMENT_FILE, encoding='utf-8').read())
    except OSError:
        return ''


def notify(title, body):
    """A desktop notification from TLA BootPaper (it also shows on the lock screen's notification list)."""
    icon = os.path.join(APP_DIR, 'AppIcon.png')
    try:
        if shutil.which('notify-send'):
            subprocess.run(['notify-send', '--app-name=TLA BootPaper', '--icon=' + icon, title, body], timeout=10)
        else:
            subprocess.run(['gdbus', 'call', '--session', '--dest', 'org.freedesktop.Notifications',
                            '--object-path', '/org/freedesktop/Notifications', '--method',
                            'org.freedesktop.Notifications.Notify', gvariant_string('TLA BootPaper'), '0',
                            gvariant_string(icon), gvariant_string(title), gvariant_string(body), '[]', '{}',
                            '-1'], capture_output=True, timeout=10)
    except Exception as e:
        log('Could not show a notification: %s' % e)


def gvariant_string(text):
    return "'" + text.replace('\\', '\\\\').replace("'", "\\'") + "'"


def set_login_banner(text):
    """Shows the announcement on the login screen (GDM's banner message), or removes it. Ubuntu 24.04 builds the
    login screen's settings from /usr/share/gdm/dconf when GDM starts (generate-config); older releases use the
    gdm dconf database."""
    if os.path.exists('/usr/share/gdm/generate-config'):
        path, rebuild = '/usr/share/gdm/dconf/95-tla-announcement', ['/usr/share/gdm/generate-config']
    else:
        path, rebuild = '/etc/dconf/db/gdm.d/95-tla-announcement', ['dconf', 'update']
    try:
        if text:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write('# TLA BootPaper: the announcement on the login screen (from GitHub)\n'
                        '[org/gnome/login-screen]\nbanner-message-enable=true\nbanner-message-text=%s\n'
                        % gvariant_string(text))
        elif os.path.exists(path):
            os.remove(path)
        else:
            return
        subprocess.run(rebuild, capture_output=True, timeout=60)
    except Exception as e:
        log('Could not update the login screen announcement: %s' % e)


def sync_announcement():
    """Root, every 15 minutes: fetch the announcement from GitHub; when it changes, save it and update the login
    screen. Offline, the last one stays."""
    try:
        raw = urllib.request.urlopen(ANNOUNCEMENT_URL, timeout=30).read().decode('utf-8', 'replace')
    except Exception as e:
        if '404' in str(e):
            raw = ''        # no announcement file: no announcement
        else:
            return
    text = clean_announcement(raw)
    if text == announcement() and os.path.exists(ANNOUNCEMENT_FILE):
        return
    os.makedirs(os.path.dirname(ANNOUNCEMENT_FILE), exist_ok=True)
    with open(ANNOUNCEMENT_FILE + '.tmp', 'w', encoding='utf-8') as f:
        f.write(text + '\n' if text else '')
    os.chmod(ANNOUNCEMENT_FILE + '.tmp', 0o644)
    os.replace(ANNOUNCEMENT_FILE + '.tmp', ANNOUNCEMENT_FILE)
    set_login_banner(text)
    log('Announcement %s.' % ('set: ' + text if text else 'cleared'))


# ---- helpdesk ---------------------------------------------------------------------------------------------------
def helpdesk_link():
    """mailto: for the helpdesk, with this computer's details filled in (4.0), so reports say where they're from."""
    from urllib.parse import quote
    body = ('\n\n\n'
            '-- Please keep these details: they help the helpdesk --\n'
            'Computer: %s\nSystem: Ubuntu %s\nTLA BootPaper: %s\nBackground: %s\nIntro video: %s\n'
            % (platform.node(), os_build(), RELEASE, BG_NAMES.get(current_background(), current_background()),
               dict(VIDEOS).get(setting('Video'), setting('Video'))))
    return 'mailto:%s?subject=%s&body=%s' % (HELPDESK, quote('TLA BootPaper (Linux)'), quote(body))


# ---- release log ------------------------------------------------------------------------------------------------
def release_notes(limit=0):
    """The shared release log, without the Windows-only and Mac-only lines. Returns [(title, [lines])]."""
    sections, cur = [], None
    try:
        lines = open(os.path.join(APP_DIR, 'release-notes.md'), encoding='utf-8').read().splitlines()
    except Exception:
        return []
    for line in lines:
        if line.startswith('# '):
            title = line[2:].strip()
            if title.startswith('[win]') or title.startswith('[mac]'):
                cur = None
                continue
            title = title.replace('[linux]', '').strip()
            # Linux starts at 3.4: older history is about the Windows and Mac versions.
            try:
                ver = tuple(int(x) for x in title.split()[-1].split('.'))
                if ver < (3, 4):
                    break
            except ValueError:
                pass
            cur = (title, [])
            sections.append(cur)
        elif cur is not None and line.startswith('- '):
            item = line[2:].strip()
            if item.startswith('[win]') or item.startswith('[mac]'):
                continue
            cur[1].append(item.replace('[linux]', '').strip())
    sections = [s for s in sections if s[1]]
    return sections[:limit] if limit else sections


# ---- root: keep backgrounds, download videos --------------------------------------------------------------------
def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def sync_videos():
    os.makedirs(VIDEO_DIR, exist_ok=True)
    missing = 0
    for vid, want in VIDEO_HASHES.items():
        target = os.path.join(VIDEO_DIR, vid + '.mp4')
        if os.path.exists(target) and sha256(target) == want:
            continue
        tmp = os.path.join(VIDEO_DIR, '.' + vid + '.download')
        try:
            urllib.request.urlretrieve('%s/%s.mp4' % (VIDEO_SOURCE, vid), tmp)
            if sha256(tmp) != want:
                raise ValueError("the file doesn't match")
            os.chmod(tmp, 0o644)
            os.replace(tmp, target)
            log('Downloaded the %s video.' % vid)
        except Exception as e:
            missing += 1
            log("Couldn't get the %s video yet (%s)." % (vid, e))
            try:
                os.remove(tmp)
            except OSError:
                pass
    # A video taken off the list (3.4.4: Solarpunk, being redone) is removed, so nobody keeps playing it.
    for name in os.listdir(VIDEO_DIR):
        vid = name[:-4]
        if name.endswith('.mp4') and vid not in VIDEO_HASHES:
            try:
                os.remove(os.path.join(VIDEO_DIR, name))
                log('Removed the %s video (no longer offered).' % vid)
            except OSError:
                pass
    return missing


def graphical_sessions():
    """(user, uid) for every active graphical login."""
    out = []
    try:
        lines = subprocess.run(['loginctl', 'list-sessions', '--no-legend'], capture_output=True, text=True,
                               timeout=10).stdout.splitlines()
    except Exception:
        return out
    for line in lines:
        f = line.split()
        if len(f) < 3:
            continue
        info = subprocess.run(['loginctl', 'show-session', f[0], '-p', 'Type', '-p', 'Active', '-p', 'Name',
                               '-p', 'User', '-p', 'Class'], capture_output=True, text=True).stdout
        p = dict(x.split('=', 1) for x in info.splitlines() if '=' in x)
        if p.get('Type') in ('wayland', 'x11') and p.get('Class') == 'user' and p.get('Active') == 'yes':
            out.append((p.get('Name'), int(p.get('User', 0))))
    return list(dict.fromkeys(out))


def as_user(user, uid, args, timeout=60):
    env = ['DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/%d/bus' % uid, 'XDG_RUNTIME_DIR=/run/user/%d' % uid,
           'HOME=' + pwd.getpwuid(uid).pw_dir]
    return subprocess.run(['runuser', '-u', user, '--', 'env'] + env + args, capture_output=True, text=True,
                          timeout=timeout)


def self_update(force=False):
    """Updates come from GitHub (3.6): every 6 hours, fetch the Intune Linux script and, if it names a different
    version from the one installed, run it. It downloads the new bundle and only installs it if its SHA-256
    matches. So once installed, TLA BootPaper keeps itself up to date without anyone signing in to the admin
    account (where the Intune agent runs)."""
    stamp = os.path.join(APP_DIR, '.update-checked')
    try:
        age = time.time() - os.path.getmtime(stamp)
    except OSError:
        age = 1e9
    if age < 6 * 3600 and not force:
        return
    try:
        open(stamp, 'w').close()
        script = urllib.request.urlopen(UPDATE_SCRIPT, timeout=30).read().decode('utf-8')
    except Exception as e:
        log("Couldn't check for updates (%s)." % e)
        return
    m = re.search(r'^VERSION="([0-9][0-9.]*)"$', script, re.M)
    if not script.startswith('#!/bin/bash') or not m or 'install.sh' not in script:
        log("Update check: GitHub's script doesn't look right; not running it.")
        return
    try:
        installed = open(os.path.join(APP_DIR, 'VERSION')).read().strip()
    except OSError:
        installed = ''
    if m.group(1) == installed:
        return
    log('Updating TLA BootPaper %s to %s.' % (installed or '?', m.group(1)))
    fd, path = tempfile.mkstemp(suffix='.sh')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(script)
        r = subprocess.run(['/bin/bash', path], capture_output=True, text=True, timeout=900)
        log('Update: %s' % (r.stdout.strip().splitlines() or ['(no output)'])[-1])
    except Exception as e:
        log('Update failed: %s' % e)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def guard():
    self_update()
    if os.geteuid() == 0:
        stamp = os.path.join(APP_DIR, '.announcement-checked')
        try:
            age = time.time() - os.path.getmtime(stamp)
        except OSError:
            age = 1e9
        if age > 900:
            open(stamp, 'w').close()
            sync_announcement()
    # Videos: every 15 minutes until they're all in place (then once a day, to pick up new ones).
    stamp = os.path.join(APP_DIR, '.videos-checked')
    try:
        age = time.time() - os.path.getmtime(stamp)
    except OSError:
        age = 1e9
    ok = os.path.exists(os.path.join(APP_DIR, '.videos-ok'))
    if age > (86400 if ok else 900):
        open(stamp, 'w').close()
        if sync_videos() == 0:
            open(os.path.join(APP_DIR, '.videos-ok'), 'w').close()
        else:
            try:
                os.remove(os.path.join(APP_DIR, '.videos-ok'))
            except OSError:
                pass
    # Backgrounds: whoever is at the screen keeps their preset (put back if changed in Settings). Installed for
    # one person, the guard runs as that person and looks after their own desktop.
    if os.geteuid() != 0:
        apply_background(if_needed=True)
        return
    for user, uid in graphical_sessions():
        if uid == 0 or not user:
            continue
        try:
            as_user(user, uid, ['/usr/bin/python3', os.path.abspath(__file__), 'apply', '--if-needed'], timeout=30)
        except Exception as e:
            log('Guard: %s' % e)


# ---- fallback player (no mpv) -----------------------------------------------------------------------------------
def gst_play(path, skip, mute, greet=''):
    """Plays the video full screen with GStreamer in a GTK window: GTK 3 (gtksink) or GTK 4 (gtk4paintablesink,
    which Ubuntu's own video player uses). Closes at the end, after 3 minutes at most, or (if allowed) on Esc,
    Space, Enter or a click. A greeting, if any, shows over the first 4.5 seconds."""
    import gi
    gi.require_version('Gst', '1.0')
    from gi.repository import Gst, GLib
    Gst.init(None)
    play = Gst.ElementFactory.make('playbin', None)
    if play is None:
        log('GStreamer has no playbin; the video can\'t play (installing mpv fixes this).')
        return 1
    play.set_property('uri', Gst.filename_to_uri(path))
    play.set_property('mute', mute)
    if mute:
        play.set_property('audio-sink', Gst.ElementFactory.make('fakesink', None))
    overlay = Gst.ElementFactory.make('textoverlay', None) if greet else None
    if overlay is not None:
        overlay.set_property('text', greet)
        overlay.set_property('font-desc', 'Sans Bold 20')
        overlay.set_property('valignment', 'bottom')
        overlay.set_property('halignment', 'center')
        overlay.set_property('ypad', 40)
        overlay.set_property('shaded-background', False)
        play.set_property('video-filter', overlay)
        GLib.timeout_add(4500, lambda: overlay.set_property('text', '') or False)
    sink = Gst.ElementFactory.make('gtksink', None)
    gtk_version = '3.0'
    if sink is None:
        sink = Gst.ElementFactory.make('gtk4paintablesink', None)
        gtk_version = '4.0'
    loop = GLib.MainLoop()
    done = {'rc': 0}

    def finish(*_):
        play.set_state(Gst.State.NULL)
        if loop.is_running():
            loop.quit()
        return False

    def on_message(_bus, msg):
        if msg.type == Gst.MessageType.EOS:
            finish()
        elif msg.type == Gst.MessageType.ERROR:
            log('GStreamer: %s' % msg.parse_error()[0].message)
            done['rc'] = 1
            finish()

    bus = play.get_bus()
    bus.add_signal_watch()
    bus.connect('message', on_message)
    GLib.timeout_add_seconds(180, finish)
    if sink is None:
        # No GTK video sink: GStreamer opens its own window.
        play.set_state(Gst.State.PLAYING)
        loop.run()
        return done['rc']
    try:
        gi.require_version('Gtk', gtk_version)
        from gi.repository import Gtk
        play.set_property('video-sink', sink)
        keys = ('Escape', 'space', 'Return', 'KP_Enter', 'q')
        if gtk_version == '3.0':
            from gi.repository import Gdk
            win = Gtk.Window(title='TLA BootPaper')
            try:
                g = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
                r = g.get_geometry()
                win.set_default_size(r.width, r.height)
            except Exception:
                pass
            css = Gtk.CssProvider()
            css.load_from_data(b'window { background: black; }')
            win.get_style_context().add_provider(css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            win.add(sink.get_property('widget'))
            win.set_keep_above(True)
            win.connect('delete-event', lambda *_: not skip or finish() or False)
            win.connect('key-press-event', lambda _w, e: skip and Gdk.keyval_name(e.keyval) in keys and finish())
            win.connect('button-press-event', lambda *_: skip and finish())
            win.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
            win.fullscreen()
            win.show_all()
            try:
                win.get_window().set_cursor(Gdk.Cursor.new_from_name(win.get_display(), 'none'))
            except Exception:
                pass
        else:
            from gi.repository import Gdk
            win = Gtk.Window(title='TLA BootPaper')
            css = Gtk.CssProvider()
            try:
                css.load_from_string('window { background: black; }')
            except Exception:
                css.load_from_data(b'window { background: black; }', -1)
            Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css,
                                                      Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            win.set_child(Gtk.Picture.new_for_paintable(sink.get_property('paintable')))
            win.connect('close-request', lambda *_: not skip or finish() or False)
            k = Gtk.EventControllerKey()
            k.connect('key-pressed', lambda _c, kv, *_: skip and Gdk.keyval_name(kv) in keys and finish())
            win.add_controller(k)
            c = Gtk.GestureClick()
            c.connect('pressed', lambda *_: skip and finish())
            win.add_controller(c)
            win.set_cursor_from_name('none')
            win.fullscreen()
            win.present()
    except Exception as e:
        # The GTK window couldn't be set up: GStreamer opens its own window instead.
        log('GTK video window unavailable (%s); using a plain GStreamer window.' % e)
        play.set_property('video-sink', Gst.ElementFactory.make('autovideosink', None))
    play.set_state(Gst.State.PLAYING)
    loop.run()
    return done['rc']


# ---- the window -------------------------------------------------------------------------------------------------
def run_app(whats_new_only=False, ask_name_only=False):
    import gi
    gi.require_version('Gtk', '3.0')
    gi.require_version('GdkPixbuf', '2.0')
    from gi.repository import Gtk, GdkPixbuf, Gdk, Pango, GLib

    css = Gtk.CssProvider()
    css.load_from_data(b"""
      .tile { padding: 2px; border: 3px solid transparent; border-radius: 9px; background: none; box-shadow: none; }
      .tile:hover { border-color: alpha(currentColor, 0.25); }
      .tile.chosen { border-color: @theme_selected_bg_color; }
      .tile-name { margin-top: 4px; }
      .tile-name.chosen { font-weight: bold; }
      .note { background: #FFF4CE; color: #1F1F1F; border: 1px solid #F2D57C; border-radius: 6px; padding: 8px 12px; }
      .help { background: #E7F0FD; color: #102A4C; border: 1px solid #9CC3F5; border-radius: 6px; padding: 10px 14px; }
      .help link { color: #0B57D0; }
      .dim { opacity: 0.7; }
      .small { font-size: 0.85em; }
      .bottom { border-top: 1px solid alpha(currentColor, 0.15); padding: 12px 24px; }
    """)
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css,
                                             Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def label(text, size=None, bold=False, dim=False, wrap=False, small=False):
        l = Gtk.Label(xalign=0)
        markup = GLib.markup_escape_text(text)
        if bold:
            markup = '<b>%s</b>' % markup
        if size:
            markup = '<span size="%d">%s</span>' % (size * 1024, markup)
        l.set_markup(markup)
        if wrap:
            l.set_line_wrap(True)
            l.set_max_width_chars(80)
        if dim:
            l.get_style_context().add_class('dim')
        if small:
            l.get_style_context().add_class('small')
        return l

    def whats_new_window(parent=None):
        w = Gtk.Window(title="What's new in TLA BootPaper")
        w.set_default_size(620, 560)
        if parent:
            w.set_transient_for(parent)
        sc = Gtk.ScrolledWindow()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=22)
        for title, items in release_notes():
            box.pack_start(label(title, 15, bold=True), False, False, 8)
            for item in items:
                parts = item.split('**')
                text = ''.join('<b>%s</b>' % GLib.markup_escape_text(p) if i % 2 else GLib.markup_escape_text(p)
                               for i, p in enumerate(parts))
                l = Gtk.Label(xalign=0)
                l.set_markup('•  ' + text)
                l.set_line_wrap(True)
                l.set_max_width_chars(70)
                box.pack_start(l, False, False, 0)
        sc.add(box)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        outer.pack_start(sc, True, True, 0)
        bar = Gtk.Box(spacing=8)
        bar.get_style_context().add_class('bottom')
        if parent is None:
            open_btn = Gtk.Button(label='Open TLA BootPaper')
            open_btn.connect('clicked', lambda *_: (w.destroy(), subprocess.Popen(
                ['/usr/bin/python3', os.path.abspath(__file__), 'app'])))
            bar.pack_end(open_btn, False, False, 0)
        ok = Gtk.Button(label='Got it')
        ok.connect('clicked', lambda *_: w.destroy())
        bar.pack_end(ok, False, False, 0)
        bar.pack_start(label('Version ' + RELEASE, dim=True, small=True), False, False, 0)
        outer.pack_start(bar, False, False, 0)
        w.add(outer)
        w.show_all()
        return w

    def name_window():
        """Asks once (4.0) what name the intro video should greet them by."""
        w = Gtk.Window(title='TLA BootPaper')
        w.set_default_size(460, -1)
        w.set_position(Gtk.WindowPosition.CENTER)
        w.set_keep_above(True)
        icon = os.path.join(APP_DIR, 'AppIcon.png')
        if os.path.exists(icon):
            w.set_icon_from_file(icon)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=24)
        box.pack_start(label('What should we call you?', 16, bold=True), False, False, 0)
        box.pack_start(label("Your intro video will greet you by this name, like “Good morning, Sam!” "
                             'You can change it any time in TLA BootPaper.', dim=True, wrap=True), False, False, 0)
        entry = Gtk.Entry(max_length=NAME_MAX, placeholder_text='Your preferred name')
        entry.set_text(str(setting('PreferredName')))
        box.pack_start(entry, False, False, 8)
        row = Gtk.Box(spacing=8)
        later = Gtk.Button(label='Not now')
        ok = Gtk.Button(label='Save')
        ok.get_style_context().add_class('suggested-action')
        row.pack_end(ok, False, False, 0)
        row.pack_end(later, False, False, 0)
        box.pack_start(row, False, False, 4)
        w.add(box)

        def save_name(*_):
            name = ' '.join(entry.get_text().split())[:NAME_MAX]
            if valid('PreferredName', name):
                save('PreferredName', name)
            set_state(NameAsked=1)
            w.destroy()

        def not_now(*_):
            set_state(NameAsked=1)
            w.destroy()
        ok.connect('clicked', save_name)
        entry.connect('activate', save_name)
        later.connect('clicked', not_now)
        w.show_all()
        return w

    if whats_new_only or ask_name_only:
        w = whats_new_window() if whats_new_only else name_window()
        w.connect('destroy', Gtk.main_quit)
        Gtk.main()
        return

    win = Gtk.Window(title='TLA BootPaper')
    win.set_default_size(790, 860)
    icon = os.path.join(APP_DIR, 'AppIcon.png')
    if os.path.exists(icon):
        win.set_icon_from_file(icon)
    win.connect('destroy', Gtk.main_quit)
    ui = {'loading': False}

    page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0, margin_start=28, margin_end=28,
                   margin_top=22, margin_bottom=18)
    page.pack_start(label('TLA BootPaper', 22, bold=True), False, False, 0)
    page.pack_start(label('Choose how your welcome video plays and pick your background for the desktop and '
                          'lock screen.', dim=True, wrap=True), False, False, 4)
    # The organization's announcement (4.0), if there is one.
    news_text = announcement()
    if news_text:
        news_note = Gtk.Label(xalign=0)
        news_note.set_markup('<b>Announcement:</b> ' + GLib.markup_escape_text(news_text))
        news_note.set_line_wrap(True)
        news_note.get_style_context().add_class('note')
        page.pack_start(news_note, False, False, 10)
    # Where to send requests, bug reports and ideas (3.4.5): always shown, near the top. The email starts with
    # this computer's details (4.0).
    help_note = Gtk.Label(xalign=0)
    help_note.set_markup('<b>Have an idea or found a problem?</b> Email <a href="%s">%s</a> to ask for a new '
                         'background, report a bug, or suggest how to make TLA computers better to use.'
                         % (GLib.markup_escape_text(helpdesk_link()), HELPDESK))
    help_note.set_line_wrap(True)
    help_note.get_style_context().add_class('help')
    page.pack_start(help_note, False, False, 12)
    note = Gtk.Label(label="Your organization manages these settings, so they can't be changed here.", xalign=0)
    note.set_line_wrap(True)
    note.get_style_context().add_class('note')
    page.pack_start(note, False, False, 12)

    page.pack_start(label('Welcome video', 15, bold=True), False, False, 8)
    enabled = Gtk.CheckButton(label='Play the welcome video when I log in')
    page.pack_start(enabled, False, False, 4)
    opts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=26, margin_top=8)
    opts.pack_start(label('Which video', dim=True), False, False, 0)
    video = Gtk.ComboBoxText()
    video.set_halign(Gtk.Align.START)
    for vid, name in VIDEOS:
        video.append(vid, name)
    opts.pack_start(video, False, False, 0)
    opts.pack_start(label('When to play it', dim=True), False, False, 8)
    radios, group = {}, None
    for pid, name in PLAY_WHEN:
        r = Gtk.RadioButton.new_with_label_from_widget(group, name)
        group = group or r
        radios[pid] = r
        opts.pack_start(r, False, False, 0)
    opts.pack_start(label('While it plays', dim=True), False, False, 8)
    sound = Gtk.CheckButton(label='Play with sound')
    skip = Gtk.CheckButton(label='Let me close it early with Esc or a click')
    opts.pack_start(sound, False, False, 0)
    opts.pack_start(skip, False, False, 0)
    # Quiet hours (4.0): off unless they turn it on.
    opts.pack_start(label('Quiet hours (for class time)', dim=True), False, False, 8)
    quiet = Gtk.ComboBoxText()
    quiet.set_halign(Gtk.Align.START)
    for qid, name in QUIET_MODES:
        quiet.append(qid, name)
    opts.pack_start(quiet, False, False, 0)
    hours = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=4)
    times = Gtk.Box(spacing=8)
    q_start, q_end = Gtk.ComboBoxText(), Gtk.ComboBoxText()
    for t in TIMES:
        q_start.append(t, t)
        q_end.append(t, t)
    times.pack_start(label('From'), False, False, 0)
    times.pack_start(q_start, False, False, 0)
    times.pack_start(label('to'), False, False, 0)
    times.pack_start(q_end, False, False, 0)
    hours.pack_start(times, False, False, 0)
    day_row = Gtk.Box(spacing=4)
    day_buttons = {}
    for d in DAYS:
        b = Gtk.ToggleButton(label=d)
        day_buttons[d] = b
        day_row.pack_start(b, False, False, 0)
    hours.pack_start(day_row, False, False, 0)
    opts.pack_start(hours, False, False, 0)
    # The greeting (4.0).
    opts.pack_start(label('Greeting', dim=True), False, False, 8)
    name_row = Gtk.Box(spacing=8)
    name_entry = Gtk.Entry(max_length=NAME_MAX, placeholder_text='Your preferred name')
    name_entry.set_width_chars(24)
    name_row.pack_start(name_entry, False, False, 0)
    # 4.0.5: a Save button and a line saying it's saved (Enter saves too, and so does closing the window).
    name_save = Gtk.Button(label='Save')
    name_save.set_sensitive(False)
    name_row.pack_start(name_save, False, False, 0)
    name_status = label('', small=True, wrap=True)
    name_row.pack_start(name_status, False, False, 0)
    opts.pack_start(name_row, False, False, 0)
    opts.pack_start(label('The video says “Good morning” with your name. Leave it empty and save for no greeting.',
                          dim=True, small=True, wrap=True), False, False, 4)
    page.pack_start(opts, False, False, 0)
    last = label('', dim=True, wrap=True)
    page.pack_start(last, False, False, 12)
    page.pack_start(Gtk.Separator(), False, False, 8)

    page.pack_start(label('Background', 15, bold=True), False, False, 8)
    bg_note = label('', dim=True, wrap=True)
    page.pack_start(bg_note, False, False, 2)

    tiles = {}

    def tile_grid():
        fb = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, column_spacing=10,
                         row_spacing=10, max_children_per_line=8, min_children_per_line=2)
        return fb

    with_video, soon = tile_grid(), tile_grid()
    for bg_id, name in BACKGROUNDS + [(SURPRISE, 'Surprise me')]:
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class('tile')
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                thumb_path(bg_id) if os.path.exists(thumb_path(bg_id)) else background_path(bg_id), 154, 87, False)
            btn.add(Gtk.Image.new_from_pixbuf(pb))
        except Exception:
            btn.add(Gtk.Label(label=name))
        btn.set_tooltip_text('A different background every day' if bg_id == SURPRISE else name)
        cap = Gtk.Label(label=name)
        cap.get_style_context().add_class('tile-name')
        cell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        cell.pack_start(btn, False, False, 0)
        cell.pack_start(cap, False, False, 0)
        btn.connect('clicked', lambda _b, i=bg_id: on_background(i))
        (with_video if bg_id in VIDEO_HASHES or bg_id == SURPRISE else soon).add(cell)
        tiles[bg_id] = (btn, cap)
    # The seasonal theme, while it's on: click it to go back to it after picking your own.
    seasonal_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    theme_now = season()
    if theme_now:
        seasonal_box.pack_start(label('Seasonal theme', dim=True), False, False, 8)
        sgrid = tile_grid()
        sbtn = Gtk.Button()
        sbtn.set_relief(Gtk.ReliefStyle.NONE)
        sbtn.get_style_context().add_class('tile')
        try:
            sbtn.add(Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(
                thumb_path(theme_now), 154, 87, False)))
        except Exception:
            sbtn.add(Gtk.Label(label=BG_NAMES[theme_now]))
        sbtn.set_tooltip_text('Until %s' % SEASON_ENDS[theme_now])
        scap = Gtk.Label(label=BG_NAMES[theme_now])
        scap.get_style_context().add_class('tile-name')
        scell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        scell.pack_start(sbtn, False, False, 0)
        scell.pack_start(scap, False, False, 0)
        sgrid.add(scell)
        seasonal_box.pack_start(sgrid, False, False, 0)
        sbtn.connect('clicked', lambda *_: on_seasonal())
        tiles['__season'] = (sbtn, scap)
    page.pack_start(seasonal_box, False, False, 0)
    page.pack_start(label('With an intro video', dim=True), False, False, 8)
    page.pack_start(with_video, False, False, 0)
    if any(b not in VIDEO_HASHES for b, _ in BACKGROUNDS):     # (only when some don't have a video yet)
        page.pack_start(label('Intro videos coming soon', dim=True), False, False, 6)
        page.pack_start(label('Until their own video is ready, these play the TLA Classic video.', dim=True,
                              small=True, wrap=True), False, False, 0)
        page.pack_start(soon, False, False, 6)

    scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
    scroll.add(page)

    bar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    bar.get_style_context().add_class('bottom')
    row = Gtk.Box(spacing=8)
    reset = Gtk.LinkButton.new_with_label('', "Use my organization's settings")
    news = Gtk.LinkButton.new_with_label('', "What's new")
    play_btn = Gtk.Button(label='Play video now')
    close = Gtk.Button(label='Close')
    row.pack_start(reset, False, False, 0)
    row.pack_start(news, False, False, 0)
    row.pack_end(close, False, False, 0)
    row.pack_end(play_btn, False, False, 0)
    bar.pack_start(row, False, False, 0)
    bar.pack_start(label('Version ' + RELEASE, dim=True, small=True), False, False, 0)

    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    outer.pack_start(scroll, True, True, 0)
    outer.pack_start(bar, False, False, 0)
    win.add(outer)

    def refresh():
        ui['loading'] = True
        locked = not users_can_change()
        bg_locked = background_locked()
        note.set_visible(locked)
        enabled.set_active(setting('Enabled') == 1)
        sound.set_active(setting('Sound') == 1)
        skip.set_active(setting('AllowSkip') == 1)
        radios[setting('PlayWhen')].set_active(True)
        bg = setting('Background')
        now_bg = current_background()
        theme = season()
        seasonal_on = bool(theme) and now_bg == theme
        org_video = org('Video')
        video.remove_all()
        for vid, name in VIDEOS:
            text = name
            if vid == 'match':
                match = match_video()
                text += ' (%s)' % (BG_NAMES[match] if os.path.exists(video_path(match)) else 'TLA Classic')
            if vid == org_video:
                text += ' - default'
            video.append(vid, text)
        video.set_active_id(setting('Video'))
        enabled.set_sensitive(not locked)
        on = not locked and setting('Enabled') == 1
        for c in [video, sound, skip, quiet, name_entry] + list(radios.values()):
            c.set_sensitive(on)
        quiet.set_active_id(setting('QuietMode'))
        q_start.set_active_id(setting('QuietStart'))
        q_end.set_active_id(setting('QuietEnd'))
        chosen_days = setting('QuietDays').split(',')
        for d, b in day_buttons.items():
            b.set_active(d in chosen_days)
            b.set_sensitive(on)
        q_start.set_sensitive(on)
        q_end.set_sensitive(on)
        hours.set_visible(setting('QuietMode') == 'Hours')
        if name_entry.get_text() != setting('PreferredName') and not name_entry.has_focus():
            name_entry.set_text(setting('PreferredName'))
        name_save.set_sensitive(on and typed_name() != setting('PreferredName'))
        st = state()
        last.set_text('Your video last played %s.' % st['LastPlayed'] if st.get('LastPlayed')
                      else "The video hasn't played for you on this computer yet.")
        if bg_locked:
            text = "Another policy on this computer locks the desktop picture, so the background can't be changed here."
        elif seasonal_on:
            text = ("It's %s time! Your desktop and lock screen show the %s theme until %s. Pick a background below "
                    'to use your own instead.' % (BG_NAMES[theme].lower() if theme == 'fall' else BG_NAMES[theme],
                                                  BG_NAMES[theme], SEASON_ENDS[theme]))
        elif theme:
            text = ('Your background is used for your desktop and lock screen. Click the %s theme to use it until %s.'
                    % (BG_NAMES[theme], SEASON_ENDS[theme]))
        elif bg == SURPRISE:
            text = 'Surprise me: today’s background is %s. Tomorrow brings another.' % BG_NAMES.get(now_bg, now_bg)
        else:
            text = 'Your background is used for your desktop and lock screen. Click one to use it.'
        bg_note.set_text(text)
        org_bg = org('Background')
        for bid, (btn, cap) in tiles.items():
            chosen = seasonal_on if bid == '__season' else (bid == bg and not seasonal_on)
            for w in (btn, cap):
                (w.get_style_context().add_class if chosen else w.get_style_context().remove_class)('chosen')
            if bid != '__season':
                cap.set_text(BG_NAMES[bid] + (' (default)' if bid == org_bg else ''))
            btn.set_sensitive(not locked and not bg_locked)
        help_note.set_markup('<b>Have an idea or found a problem?</b> Email <a href="%s">%s</a> to ask for a new '
                             'background, report a bug, or suggest how to make TLA computers better to use.'
                             % (GLib.markup_escape_text(helpdesk_link()), HELPDESK))
        reset.set_visible(not locked and any(k != 'PreferredName' for k in mine()))
        play_btn.set_sensitive(os.path.exists(video_file()))
        ui['loading'] = False

    def change(name, value):
        if ui['loading'] or not users_can_change():
            return
        save(name, value)
        refresh()

    def on_background(bg_id):
        if not users_can_change() or background_locked():
            return
        save('Background', bg_id)
        apply_background()
        refresh()

    def on_seasonal():
        """Back to the seasonal theme: forget the background they picked (they're on the default again)."""
        if not users_can_change() or background_locked():
            return
        s = mine()
        s.pop('Background', None)
        write_json(os.path.join(config_dir(), 'settings.json'), s)
        apply_background()
        refresh()

    def on_reset(*_):
        # Back to the organization's settings, but their name for the greeting stays.
        keep = {k: v for k, v in mine().items() if k == 'PreferredName' and valid(k, v)}
        write_json(os.path.join(config_dir(), 'settings.json'), keep)
        apply_background(if_needed=True)
        refresh()
        return True

    def on_days(*_):
        change('QuietDays', ','.join(d for d in DAYS if day_buttons[d].get_active()))

    def typed_name():
        return ' '.join(name_entry.get_text().split())[:NAME_MAX]

    def on_name(*_):
        if ui['loading']:
            return
        name_status.set_text('')
        name_save.set_sensitive(users_can_change() and typed_name() != setting('PreferredName'))

    def save_name(*_):
        if not users_can_change():
            return
        name = typed_name()
        if not valid('PreferredName', name):
            return
        save('PreferredName', name)
        set_state(NameAsked=1)          # (no need to ask at login now)
        name_entry.set_text(name)
        name_status.set_markup('<span foreground="#2E7D32">%s</span>' % GLib.markup_escape_text(
            'Saved ✓  Your video will say: %s' % greeting() if name else 'Saved ✓  No greeting.'))
        name_save.set_sensitive(False)

    enabled.connect('toggled', lambda b: change('Enabled', int(b.get_active())))
    sound.connect('toggled', lambda b: change('Sound', int(b.get_active())))
    skip.connect('toggled', lambda b: change('AllowSkip', int(b.get_active())))
    quiet.connect('changed', lambda c: c.get_active_id() and change('QuietMode', c.get_active_id()))
    q_start.connect('changed', lambda c: c.get_active_id() and change('QuietStart', c.get_active_id()))
    q_end.connect('changed', lambda c: c.get_active_id() and change('QuietEnd', c.get_active_id()))
    for b in day_buttons.values():
        b.connect('toggled', on_days)
    name_entry.connect('changed', on_name)
    name_entry.connect('activate', save_name)
    name_save.connect('clicked', save_name)
    win.connect('delete-event', lambda *_: (name_save.get_sensitive() and save_name(), False)[1])
    video.connect('changed', lambda c: c.get_active_id() and change('Video', c.get_active_id()))
    for pid, r in radios.items():
        r.connect('toggled', lambda b, p=pid: b.get_active() and change('PlayWhen', p))
    reset.connect('activate-link', on_reset)
    news.connect('activate-link', lambda *_: (whats_new_window(win), True)[1])
    play_btn.connect('clicked', lambda *_: (play_video(force=True), refresh()))
    close.connect('clicked', lambda *_: win.destroy())
    win.connect('key-press-event', lambda w, e: e.keyval == Gdk.KEY_Escape and (w.destroy() or True))

    refresh()
    win.show_all()
    refresh()   # (show_all shows the hidden bits again)
    if os.environ.get('TLA_SNAPSHOT'):   # developer check: picture of the window, then quit
        def snap():
            win.get_window().get_screen()
            os.system('xwd -root -silent | convert xwd:- "%s"' % os.environ['TLA_SNAPSHOT'])
            Gtk.main_quit()
        GLib.timeout_add(1500, snap)
    Gtk.main()


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'app'
    if cmd == 'app':
        run_app()
    elif cmd == 'whatsnew':
        run_app(whats_new_only=True)
    elif cmd == 'login':
        login()
    elif cmd == 'play':
        play_video(force=True)
    elif cmd == 'apply':
        apply_background(if_needed='--if-needed' in sys.argv)
    elif cmd == 'guard':
        guard()
    elif cmd == 'update':
        self_update(force=True)
    elif cmd == 'gst-play':
        sys.exit(gst_play(sys.argv[2], sys.argv[3] == '1', sys.argv[4] == '1', sys.argv[5] if len(sys.argv) > 5 else ''))
    elif cmd == 'sync-videos':
        sys.exit(1 if sync_videos() else 0)
    elif cmd == 'ask-name':
        run_app(ask_name_only=True)
    elif cmd == 'announcement':
        sync_announcement()
        print(announcement() or '(no announcement)')
    else:
        sys.exit('usage: tla-bootpaper.py app|whatsnew|login|play|apply|guard|sync-videos|update|ask-name|announcement')


if __name__ == '__main__':
    main()
