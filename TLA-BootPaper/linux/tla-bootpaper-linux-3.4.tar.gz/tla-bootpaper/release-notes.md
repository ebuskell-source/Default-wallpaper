# [linux] Version 3.4
- [linux] **TLA BootPaper is now on Linux.** Your TLA intro video plays when you log in, and you choose your background for the desktop and lock screen in the **TLA BootPaper** app (in Activities).

# [mac] Version 3.3.3
- [mac] **The lock screen shows your current background.** It could show an older one than your desktop.

# [win] Version 3.3.1
- [win] **Two new backgrounds: Anime and Ocean**, in the **Intro videos coming soon** section.

# [mac] Version 3.3.2
- [mac] **Two new backgrounds: Anime and Ocean**, in the **Intro videos coming soon** section.

# [mac] Version 3.3.1
- [mac] **A new look for TLA BootPaper**, like the Windows app: click a picture to choose your background, and changes save straight away. **Play video now** and **What's new** are at the bottom.

# Version 3.3
- **Three new intro videos: Code, Bricks and Blocks.** Pick one of those backgrounds (or choose it under **Which video**) to see it.
- **A new background: Solarpunk**, in the **Intro videos coming soon** section.

# [mac] Version 3.2.9
- [mac] **The intro video starts the moment you log in**, before the desktop appears. A new, faster player takes over the screen in a fraction of a second.

# [mac] Version 3.2.8
- [mac] **The intro video starts the moment you log in**, covering the screen before the desktop appears.
- [mac] **Play my video** in TLA BootPaper plays your intro video straight away, full screen.
- [mac] **See all the backgrounds** is a link at the top of the TLA BootPaper window.

# [mac] Version 3.2.7
- [mac] **The intro video really is full screen now**, over the menu bar and Dock, and starts as soon as you log in.
- [mac] **Save keeps TLA BootPaper open**, so you can keep trying backgrounds. Click **Close** when you're done.

# [mac] Version 3.2.6
- [mac] **See the backgrounds is back** at the bottom left of the TLA BootPaper window.
- [mac] **What's new** (the ? button) fits on the screen again, with a button to close it.

# [mac] Version 3.2.5
- [mac] **The intro video plays full screen**, over the menu bar and Dock, on every display.
- [mac] **The intro video plays to the end** unless you turn on the Skip button in TLA BootPaper.
- [mac] Your TLA background is set on the desktop as soon as you log in.
- [mac] If a Mac's settings lock the desktop picture, TLA BootPaper now says so instead of failing quietly.

# [mac] Version 3.2.4
- [mac] TLA BootPaper no longer asks to install Rosetta on Macs with Apple silicon.

# Version 3.2.3
- **Rainy has its own intro video now.** Pick Rainy as your background (or under **Which video**) to see it.
- **Three new backgrounds: Bricks, Claymation and Blocks**, in the **Intro videos coming soon** section.
- **Backgrounds fit your screen properly.** They no longer look zoomed in on screens that aren't widescreen: the logo is now the same size as in your intro video.
- [win] **Your background is yours alone again.** On a shared PC, everyone keeps their own desktop and lock screen; picking one no longer changes it for other people.
- [win] Your desktop and lock screen both change as soon as you pick a background.
- [mac] **The intro video now fills the screen.**
- [mac] **A tidier TLA BootPaper window.** Click **See the backgrounds** for pictures of all of them; **What's new** is under the **?** button.

# [mac] Version 3.2.2
- [mac] Your chosen background now stays in place more reliably. If the desktop picture is changed anywhere other than TLA BootPaper, your TLA background comes back within a few seconds.

# Version 3.2.1
- **Backgrounds can only be changed in TLA BootPaper.** Your desktop and lock screen always use one of the TLA backgrounds, and you pick which one in the app.
- [win] **The lock screen shows your TLA background again** when the PC starts up, before anyone signs in.
- [win] Your desktop changes as soon as you pick a background, and your lock screen the next time the PC locks or restarts.

# Version 3.2
- **Your lock screen matches your desktop.** The background you pick is now used for your lock screen too.
- **Three new backgrounds: Rainy, Space and Code.** They're in their own section, **Intro videos coming soon**, and play the TLA Classic video until their own is ready.
- **Sharper backgrounds.** Frutiger Aero, Liquid Glass and Microsoft have new, crisper versions.
- [win] **The TLA BootPaper window can now be resized**, and it scrolls instead of running off the bottom of smaller screens.
- [mac] **The TLA BootPaper window can now be moved and resized**, and it fits on smaller screens.
- [mac] On Macs, the lock screen always shows your desktop background, so the one you pick shows there too.

# Version 3.1
- **Welcome Video is now TLA BootPaper**, with a new TLA icon, because it now does your intro video and your desktop background.
- **Pick your intro video.** Four TLA intro videos to choose from: TLA Classic, Frutiger Aero, Liquid Glass and Microsoft.
- **Matches your background.** Unless you pick one, your intro video matches your desktop background.
- **Rainy is taking a break.** The Rainy background has been removed for now. If you were using it, you now have the default background.
- [win] To change your video, click Start, type **TLA BootPaper**, and look under **Which video**.
- [mac] To change your video, open **TLA BootPaper** from Applications or Launchpad and look under **Which video**.

# [win] Version 3.0.2
- [win] Fixed updates that failed when the Welcome Video app was open, which left out the background pictures.

# [win] Version 3.0.1
- [win] Fixed the background previews in the Welcome Video app, which showed up blank.

# Version 3.0
- **Pick your desktop background.** Choose from the TLA backgrounds in the Welcome Video app.
- [win] **Your background is now Microsoft.** You can switch to another one in the Welcome Video app.
- [mac] **Your background is now Liquid Glass.** You can switch to another one in the Welcome Video app.
- [mac] **The Welcome Video app is now on Macs**, with the same choices as on school PCs.
- **About the welcome video:** it plays when you sign in. In the app you can turn it off, choose when it plays (every sign-in, once a day, only after updates, or just once), turn the sound off, and choose whether it can be closed early.
- **What's new:** after each update, this list shows you what changed. You can open it again from the app.
- [win] To open the app, click Start and type **Welcome Video**.
- [mac] To open the app, open **Welcome Video** from Applications or Launchpad, or search for it with Spotlight.

# [win] Version 2.0
- [win] Added the Welcome Video app, where you choose whether and when the video plays.

# [win] Version 1.5
- [win] The video now starts much sooner after you sign in.
