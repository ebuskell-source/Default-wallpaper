# [linux] Version 4.2
- [linux] **Preview any intro video.** Click the play button on a background's picture to watch its video, without changing your background.
- [linux] **Play without sound.** A new link under **Play video now** plays your video muted, handy in class.
- [linux] **Use a background for a while.** Under **Use my pick**, choose **Just for today** or **For one week** before you click a background. After that, your usual background comes back by itself (or click **Go back now**).
- [linux] **Fit on the screen.** Choose whether your background fills the screen, shows the whole picture, or stretches across all your screens.

# [linux] Version 4.1
- [linux] **Seasonal intro videos.** Fall, Christmas and Easter now have their own intro videos. While a seasonal theme is on your desktop, **Match my background** plays its video.
- [linux] **A new Bricks intro video.**
- [linux] **Frutiger Aero's first intro video is back** as the main one. Prefer the newer one? Choose **Frutiger Aero (newer version)** under **Which video**.

# [linux] Version 4.0.5
- [linux] **A Save button for your name.** Type the name for your greeting and click **Save** (or press Enter); TLA BootPaper shows what your video will say.
- [linux] **The name question waits for you.** If the “What should we call you?” window closes before you answer, it asks again next time.

# [linux] Version 4.0
- [linux] **A new background: 8-Bit**, with its own intro video.
- [linux] **New intro videos for Liquid Glass and Microsoft**, and **Solarpunk has its video back** (remade). The first Liquid Glass and Microsoft videos are still there under **Which video**, marked (original).
- [linux] **Seasonal themes: Fall, Christmas and Easter.** If you haven't picked a background yourself, your desktop and lock screen switch to the season's theme automatically (Fall from September 22 to November 30, Christmas from December 1 to January 6, Easter for the two weeks before Easter until Easter Monday). Pick any background to keep your own.
- [linux] **Surprise me.** Choose **Surprise me** for a new background every day, or for a different intro video each time it plays.
- [linux] **Your intro video says hello.** Tell TLA BootPaper what to call you and the video greets you by name, like “Good morning, Sam!”. It asks once; you can change or remove your name any time.
- [linux] **Quiet hours.** Mute the intro video during class time: pick the hours and days, or mute it whenever Do Not Disturb is on. It's off unless you turn it on.
- [linux] **Announcements.** When the school has an announcement, it shows on the login screen, when you log in, and at the top of TLA BootPaper.
- [linux] **Better helpdesk emails.** The helpdesk link starts an email with your computer's details already filled in, so the helpdesk can help faster.

# [linux] Version 3.7
- [linux] **An Underwater intro video.** It plays with the Underwater background (it was called Ocean), or choose it under **Which video**.
- [linux] **Backgrounds in a new order.** Microsoft, Liquid Glass and Penguins come first, then the rest grouped by look: futuristic, sky and space, nature, then the ones with people in them.
- [linux] **One version number everywhere again:** 3.7 on Mac, Windows and Linux.

# [linux] Version 3.6
- [linux] **A Penguins intro video.** It plays with the Penguins background (or choose it under **Which video**).
- [linux] **Updates itself.** Once installed, TLA BootPaper checks for new versions every few hours and installs them for everyone, so nobody needs to sign in to the admin account for updates.

# [mac] Version 3.6
- [mac] **A Penguins intro video.** It plays with the Penguins background (or choose it under **Which video**).

# [win] Version 3.6
- [win] **A Penguins intro video.** It plays with the Penguins background (or choose it under **Which video**).

# [linux] Version 3.5.5
- [linux] **Works for every account.** TLA BootPaper is installed once for everyone on the computer, so students don't need an admin password. If mpv isn't installed, the intro video plays with Ubuntu's own video system instead.

# [linux] Version 3.5
- [linux] **One version number everywhere.** TLA BootPaper is now version 3.5 on Mac, Windows and Linux, so it's easy to tell everyone's up to date.

# [mac] Version 3.5
- [mac] **One version number everywhere.** TLA BootPaper is now version 3.5 on Mac, Windows and Linux, so it's easy to tell everyone's up to date.
- [mac] **A new background: Penguins**, in the **Intro videos coming soon** section (it's the default on the Linux computers).

# [win] Version 3.5
- [win] **One version number everywhere.** TLA BootPaper is now version 3.5 on Mac, Windows and Linux, so it's easy to tell everyone's up to date.
- [win] **A new background: Penguins**, in the **Intro videos coming soon** section (it's the default on the Linux computers).

# [linux] Version 3.4.5
- [linux] **A new Penguins background, now the default on Linux.** Its own intro video is coming soon; until then it plays the TLA Classic video. You can still pick any other background.
- [linux] **Ideas or problems? Tell the helpdesk.** The TLA BootPaper app now shows how to reach helpdesk@schoolathome.ca to ask for a new background, report a bug, or suggest how to make TLA computers better to use.

# [mac] Version 3.3.9
- [mac] **Ideas or problems? Tell the helpdesk.** The TLA BootPaper app now shows how to reach helpdesk@schoolathome.ca to ask for a new background, report a bug, or suggest how to make TLA computers better to use.

# [win] Version 3.3.6
- [win] **Ideas or problems? Tell the helpdesk.** The TLA BootPaper app now shows how to reach helpdesk@schoolathome.ca to ask for a new background, report a bug, or suggest how to make TLA computers better to use.

# [linux] Version 3.4.4
- [linux] **The Solarpunk intro video is off the list for now** while it's redone. Solarpunk is back under **Intro videos coming soon** (the background itself hasn't changed), and anyone who had it now sees the TLA Classic video.

# [mac] Version 3.3.8
- [mac] **The Solarpunk intro video is off the list for now** while it's redone. Solarpunk is back under **Intro videos coming soon** (the background itself hasn't changed), and anyone who had it now sees the TLA Classic video.

# [win] Version 3.3.5
- [win] **The Solarpunk intro video is off the list for now** while it's redone. Solarpunk is back under **Intro videos coming soon** (the background itself hasn't changed), and anyone who had it now sees the TLA Classic video.

# [linux] Version 3.4.3
- [linux] **New intro videos for Frutiger Aero, Liquid Glass and Microsoft.** They play with those backgrounds from now on. Prefer the first versions? Choose "(original)" under **Which video**.
- [linux] **Two more intro videos: Claymation and Solarpunk.** Only Ocean is still coming soon.

# [linux] Version 3.4.2
- [linux] **Two new intro videos: Space and Anime.** Pick one of those backgrounds (or choose it under **Which video**) to see it.
- [linux] **A new Anime background** made for widescreen, so it fills the screen.

# [linux] Version 3.4.1
- [linux] **The Anime background fills the screen**, with no blurry edges.

# [linux] Version 3.4
- [linux] **TLA BootPaper is now on Linux.** Your TLA intro video plays when you log in, and you choose your background for the desktop and lock screen in the **TLA BootPaper** app (in Activities).

# [mac] Version 3.3.7
- [mac] **New intro videos for Frutiger Aero, Liquid Glass and Microsoft.** They play with those backgrounds from now on. Prefer the first versions? Choose "(original)" under **Which video**.
- [mac] **Two more intro videos: Claymation and Solarpunk.** Only Ocean is still coming soon.

# [win] Version 3.3.4
- [win] **New intro videos for Frutiger Aero, Liquid Glass and Microsoft.** They play with those backgrounds from now on. Prefer the first versions? Choose "(original)" under **Which video**.
- [win] **Two more intro videos: Claymation and Solarpunk.** Only Ocean is still coming soon.

# [mac] Version 3.3.6
- [mac] **Two new intro videos: Space and Anime.** Pick one of those backgrounds (or choose it under **Which video**) to see it.
- [mac] **A new Anime background** made for widescreen, so it fills the screen.

# [win] Version 3.3.3
- [win] **Two new intro videos: Space and Anime.** Pick one of those backgrounds (or choose it under **Which video**) to see it.
- [win] **A new Anime background** made for widescreen, so it fills the screen.

# [mac] Version 3.3.5
- [mac] **The Anime background fills the screen**, with no blurry edges.

# [win] Version 3.3.2
- [win] **The Anime background fills the screen**, with no blurry edges.

# [mac] Version 3.3.4
- [mac] **The Anime background shows its whole picture**, with plain dark panels at the sides instead of a blurry mirror.

# [mac] Version 3.3.3
- [mac] **The lock screen shows your current background.** It could show an older one than your desktop.

# [win] Version 3.3.1
- [win] **Two new backgrounds: Anime and Ocean**, in the **Intro videos coming soon** section.

# [mac] Version 3.3.2
- [mac] **Two new backgrounds: Anime and Ocean**, in the **Intro videos coming soon** section.

# [mac] Version 3.3.1
- [mac] **A new look for TLA BootPaper**, like the Windows app: click a picture to choose your background, and changes save straight away. **Play video now** and **What's new** are at the bottom.

# Version 3.3
- **Three new intro videos: Code, Bricks and Blocks.** Pick one of those backgrounds (or choose it under **Which video**) to see it.
- **A new background: Solarpunk**, in the **Intro videos coming soon** section.

# [mac] Version 3.2.9
- [mac] **The intro video starts the moment you log in**, before the desktop appears. A new, faster player takes over the screen in a fraction of a second.

# [mac] Version 3.2.8
- [mac] **The intro video starts the moment you log in**, covering the screen before the desktop appears.
- [mac] **Play my video** in TLA BootPaper plays your intro video straight away, full screen.
- [mac] **See all the backgrounds** is a link at the top of the TLA BootPaper window.

# [mac] Version 3.2.7
- [mac] **The intro video really is full screen now**, over the menu bar and Dock, and starts as soon as you log in.
- [mac] **Save keeps TLA BootPaper open**, so you can keep trying backgrounds. Click **Close** when you're done.

# [mac] Version 3.2.6
- [mac] **See the backgrounds is back** at the bottom left of the TLA BootPaper window.
- [mac] **What's new** (the ? button) fits on the screen again, with a button to close it.

# [mac] Version 3.2.5
- [mac] **The intro video plays full screen**, over the menu bar and Dock, on every display.
- [mac] **The intro video plays to the end** unless you turn on the Skip button in TLA BootPaper.
- [mac] Your TLA background is set on the desktop as soon as you log in.
- [mac] If a Mac's settings lock the desktop picture, TLA BootPaper now says so instead of failing quietly.

# [mac] Version 3.2.4
- [mac] TLA BootPaper no longer asks to install Rosetta on Macs with Apple silicon.

# Version 3.2.3
- **Rainy has its own intro video now.** Pick Rainy as your background (or under **Which video**) to see it.
- **Three new backgrounds: Bricks, Claymation and Blocks**, in the **Intro videos coming soon** section.
- **Backgrounds fit your screen properly.** They no longer look zoomed in on screens that aren't widescreen: the logo is now the same size as in your intro video.
- [win] **Your background is yours alone again.** On a shared PC, everyone keeps their own desktop and lock screen; picking one no longer changes it for other people.
- [win] Your desktop and lock screen both change as soon as you pick a background.
- [mac] **The intro video now fills the screen.**
- [mac] **A tidier TLA BootPaper window.** Click **See the backgrounds** for pictures of all of them; **What's new** is under the **?** button.

# [mac] Version 3.2.2
- [mac] Your chosen background now stays in place more reliably. If the desktop picture is changed anywhere other than TLA BootPaper, your TLA background comes back within a few seconds.

# Version 3.2.1
- **Backgrounds can only be changed in TLA BootPaper.** Your desktop and lock screen always use one of the TLA backgrounds, and you pick which one in the app.
- [win] **The lock screen shows your TLA background again** when the PC starts up, before anyone signs in.
- [win] Your desktop changes as soon as you pick a background, and your lock screen the next time the PC locks or restarts.

# Version 3.2
- **Your lock screen matches your desktop.** The background you pick is now used for your lock screen too.
- **Three new backgrounds: Rainy, Space and Code.** They're in their own section, **Intro videos coming soon**, and play the TLA Classic video until their own is ready.
- **Sharper backgrounds.** Frutiger Aero, Liquid Glass and Microsoft have new, crisper versions.
- [win] **The TLA BootPaper window can now be resized**, and it scrolls instead of running off the bottom of smaller screens.
- [mac] **The TLA BootPaper window can now be moved and resized**, and it fits on smaller screens.
- [mac] On Macs, the lock screen always shows your desktop background, so the one you pick shows there too.

# Version 3.1
- **Welcome Video is now TLA BootPaper**, with a new TLA icon, because it now does your intro video and your desktop background.
- **Pick your intro video.** Four TLA intro videos to choose from: TLA Classic, Frutiger Aero, Liquid Glass and Microsoft.
- **Matches your background.** Unless you pick one, your intro video matches your desktop background.
- **Rainy is taking a break.** The Rainy background has been removed for now. If you were using it, you now have the default background.
- [win] To change your video, click Start, type **TLA BootPaper**, and look under **Which video**.
- [mac] To change your video, open **TLA BootPaper** from Applications or Launchpad and look under **Which video**.

# [win] Version 3.0.2
- [win] Fixed updates that failed when the Welcome Video app was open, which left out the background pictures.

# [win] Version 3.0.1
- [win] Fixed the background previews in the Welcome Video app, which showed up blank.

# Version 3.0
- **Pick your desktop background.** Choose from the TLA backgrounds in the Welcome Video app.
- [win] **Your background is now Microsoft.** You can switch to another one in the Welcome Video app.
- [mac] **Your background is now Liquid Glass.** You can switch to another one in the Welcome Video app.
- [mac] **The Welcome Video app is now on Macs**, with the same choices as on school PCs.
- **About the welcome video:** it plays when you sign in. In the app you can turn it off, choose when it plays (every sign-in, once a day, only after updates, or just once), turn the sound off, and choose whether it can be closed early.
- **What's new:** after each update, this list shows you what changed. You can open it again from the app.
- [win] To open the app, click Start and type **Welcome Video**.
- [mac] To open the app, open **Welcome Video** from Applications or Launchpad, or search for it with Spotlight.

# [win] Version 2.0
- [win] Added the Welcome Video app, where you choose whether and when the video plays.

# [win] Version 1.5
- [win] The video now starts much sooner after you sign in.
